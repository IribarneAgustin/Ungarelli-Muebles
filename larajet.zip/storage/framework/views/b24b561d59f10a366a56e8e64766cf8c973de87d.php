

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Editar reparación</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form action="/repairs/<?php echo e($repair->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="form-group">
        <label for="exampleInputEmail1">Descripción</label>
        <textarea value="<?php echo e($repair->description); ?>" name="description" type="text" class="form-control" id="exampleInputEmail1" required><?php echo e($repair->description); ?></textarea>
    </div>
    <div class="form-group">
        <label for="exampleInputEmail1">Seña</label>
        <input value="<?php echo e($repair->paymentSign); ?>"  name="paymentSign" type="number" min="0" class="form-control" id="exampleInputEmail1">
    </div>
    <br>
    <div class="form-group">
        <button type="submit" class="btn btn-primary">Modificar</button>
        <a href="<?php echo e(route('repairs.show',$repair->clientId)); ?>" class="btn btn-danger">Cancelar</a>
    </div>

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larajet\resources\views/repair/edit.blade.php ENDPATH**/ ?>