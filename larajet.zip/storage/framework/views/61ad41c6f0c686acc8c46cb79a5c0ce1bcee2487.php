

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Editar artículo</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form action="/clients/<?php echo e($client->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="form-group">
        <label for="exampleInputEmail1">Nombre</label>
        <input value="<?php echo e($client->name); ?>" name="name" type="text" class="form-control" id="exampleInputEmail1" required>
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">Teléfono</label>
        <input value="<?php echo e($client->phone); ?>" name="phone" type="text" class="form-control" id="exampleInputPassword1" required>
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">Email</label>
        <input value="<?php echo e($client->email); ?>" name="email" type="email" class="form-control" id="exampleInputPassword1">
    </div>
    <br>
    <div class="form-group">
        <button type="submit" class="btn btn-primary">Modificar</button>
        <a href="/clients" class="btn btn-danger">Cancelar</a>
    </div>

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larajet\resources\views\client\edit.blade.php ENDPATH**/ ?>