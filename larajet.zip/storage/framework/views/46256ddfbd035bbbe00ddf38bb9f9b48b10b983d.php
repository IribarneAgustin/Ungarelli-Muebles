

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Editar artículo</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form action="/articles/<?php echo e($article->id); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="form-group">
        <label for="exampleInputEmail1">Nombre</label>
        <input value="<?php echo e($article->name); ?>" name="name" type="text" class="form-control" id="exampleInputEmail1" required>
    </div>
    <div class="form-group">
        <label class="form-label" for="customFile">Imagen</label>
        <input value="<?php echo e($article->image); ?>" name="image" type="file" class="form-control" id="customFile" accept="image/*" />
    </div>

    <div class="form-group">
        <label for="exampleInputPassword1">Descripción</label>
        <input value="<?php echo e($article->description); ?>" name="description" type="text" class="form-control" id="exampleInputPassword1" required>
    </div>
    <div class="form-group">
        <label for="exampleFormControlSelect1">Categoría</label>
        <select name="categoryId" class="form-control" id="exampleFormControlSelect1" required>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($category->id == $categorie->id ): ?>
            <option selected="true" value="<?php echo e($categorie->id); ?>"> <?php echo e($categorie->name); ?></option>
            <?php else: ?>
            <option value="<?php echo e($categorie->id); ?>"> <?php echo e($categorie->name); ?> </option>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <label class="form-label" for="flexCheckDefault">Subcategoría (opcional)</label>
    <div class="form-check">
        <?php if($article->premium == 1): ?>
        <input checked="true" name="premium" class="form-check-input" type="checkbox" value="1" id="flexCheckDefault">
        <label class="form-check-label" for="flexCheckDefault">
            Artículo premium
        </label>
        <?php else: ?>
        <input name="premium" class="form-check-input" type="checkbox" value="1" id="flexCheckDefault">
        <label class="form-check-label" for="flexCheckDefault">
            Artículo premium
        </label>
        <?php endif; ?>
    </div>
    <br>
    <div class="form-group">
        <button type="submit" class="btn btn-primary">Modificar</button>
        <a href="/articles" class="btn btn-danger">Cancelar</a>
    </div>

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larajet\resources\views\article\edit.blade.php ENDPATH**/ ?>