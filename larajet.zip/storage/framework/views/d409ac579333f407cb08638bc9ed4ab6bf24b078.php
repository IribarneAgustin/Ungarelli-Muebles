<footer class="main-footer">
    <?php echo $__env->yieldContent('footer'); ?>
</footer><?php /**PATH C:\xampp\htdocs\larajet\vendor\jeroennoten\laravel-adminlte\resources\views\partials\footer\footer.blade.php ENDPATH**/ ?>