<?php if($errors->any()): ?>
    <div <?php echo e($attributes); ?>>
        <div class="font-medium text-red-600"><?php echo e(__('Datos ingresados incorrectamente')); ?></div>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\larajet\vendor\laravel\jetstream\resources\views\components\validation-errors.blade.php ENDPATH**/ ?>