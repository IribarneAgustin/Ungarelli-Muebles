<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta desde la página</title>
</head>
<body>
<p><strong>Nombre:</strong> <?php echo e($contact['name']); ?></p>
<p><strong>Correo:</strong> <?php echo e($contact['email']); ?></p>
<p><strong>Mensaje:</strong> <?php echo e($contact['message']); ?></p>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\larajet\resources\views/email/contact.blade.php ENDPATH**/ ?>