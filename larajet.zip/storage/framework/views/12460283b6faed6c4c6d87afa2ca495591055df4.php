

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Agregar Reparación</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="/repairs" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="clientId" value="<?php echo e($clientId); ?>">

    <div class="form-group">
        <label for="exampleInputEmail1">Descripción</label>
        <textarea name="description" type="text" class="form-control" id="exampleInputEmail1" required></textarea>
    </div>

    <div class="form-group">
        <label for="exampleInputPassword1">Estado</label>
        <select class="form-select" name="status" id="exampleInputPassword1" required>
            <option name="status" value="En espera">En espera</option>
            <option name="status" value="En proceso">En proceso</option>
        </select>

    </div>

    <div class="form-group">
        <label for="exampleInputEmail1">Seña (opcional)</label>
        <input name="payment sign" type="number" min="0" class="form-control" id="exampleInputEmail1">
    </div>

    <br>
    <div class="form-group">
        <button type="submit" class="btn btn-primary">Agregar</button>
        <a href="/repairs" class="btn btn-danger">Cancelar</a>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larajet\resources\views\repair\create.blade.php ENDPATH**/ ?>