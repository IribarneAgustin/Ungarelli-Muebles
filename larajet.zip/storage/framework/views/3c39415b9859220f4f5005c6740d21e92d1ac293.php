

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Artículos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <a href="articles/create" class="btn btn-primary">Agregar</a>
    <hr>
    <table id="articles" class="table table-striped table-bordered shadow-lg mt-4" style="width:100%">
        <thead class="bg-primary text-white">
            <tr>
                <th scope="col" style="width: 5%">Id</th>
                <th scope="col" style="width: 10%">Categoría</th>
                <th scope="col" style="width: 5%">Premium</th>
                <th scope="col" style="width: 10%">Nombre</th>
                <th scope="col" style="width: 20%">Descripción</th>
                <th scope="col" style="width: 20%">Imagen</th>
                <th scope="col" style="width: 20%"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <?php echo e($article->id); ?> </td>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($category->id == $article->categoryId): ?>
                <td><?php echo e($category->name); ?> </td>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td> <?php if($article->premium == 1): ?> Si
                    <?php else: ?> No
                    <?php endif; ?> </td>
                <td> <?php echo e($article->name); ?> </td>
                <td> <?php echo e($article->description); ?> </td>
                <td> <img src="<?php echo e(asset($article->image)); ?>" width="100%" height="auto"></td>
                <td>
                    <form action="<?php echo e(route('articles.destroy',$article->id)); ?>" method="post" class="delete-form">
                        <a href="/articles/<?php echo e($article->id); ?>/edit" style="width: 40%" class="btn btn-info">Editar</a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" style="width: 40%" class="btn btn-danger">Borrar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<link href="https://cdn.datatables.net/1.10.23/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.23/js/dataTables.bootstrap5.min.js"></script>
<!--Sweet Alert 2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<!-- Datatables -->
<script>
    $('#articles').DataTable({
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "Nada encontrado - disuclpa",
            "info": "Mostrando la página _PAGE_ de _PAGES_",
            "infoEmpty": "No se encontró ningún registro",
            "infoFiltered": "(filtrado de _MAX_ registros totales)",
            "search": "Buscar:",
            "paginate": {
                'next': "Siguiente",
                'previous': "Anterior"
            }
        }

    });
</script>


<?php if(session('delete') == 'ok'): ?>
<script>
    Swal.fire(
        'Artículo borrado',
        'El artículo fue borrado exitosamente.',
        'success'
    )
</script>
<?php endif; ?>
<script>
    $('.delete-form').submit(function(e) {
        e.preventDefault();

        Swal.fire({
            title: '¿Desea borrar este artículo?',
            text: " ",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Borrar',
            cancelButtonText: 'Canelar'
        }).then((result) => {
            if (result.isConfirmed) {
                this.submit();
            }
        })

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larajet\resources\views\article\index.blade.php ENDPATH**/ ?>