

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Agregar artículo</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="\articles" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="exampleInputEmail1">Nombre</label>
        <input name="name" type="text" class="form-control" id="exampleInputEmail1" required>
    </div>

    <div class="form-group">
        <label for="exampleInputPassword1">Descripción</label>
        <input name="description" type="text" class="form-control" id="exampleInputPassword1" required>
    </div>
    <div class="form-group">
        <label class="form-label" for="customFile">Imagen</label>
        <input name="image" type="file" class="form-control" id="customFile" accept="image/*" required />
    </div>
    <div class="form-group">
        <label for="exampleFormControlSelect1">Categoría</label>

        <select name="categoryId" class="form-control" id="exampleFormControlSelect1" required>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>"> <?php echo e($category->name); ?> </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

    </div>

    <label class="form-label" for="flexCheckDefault">Subcategoría (opcional)</label>
    <br>

    <div class="form-check">
        <input name="premium" class="form-check-input" type="checkbox" value="1" id="flexCheckDefault">
        <label class="form-check-label" for="flexCheckDefault">
            Artículo premium
        </label>
    </div>

    <br>
    <div class="form-group">
        <button type="submit" class="btn btn-primary">Agregar</button>
        <a href="/articles" class="btn btn-danger">Cancelar</a>
    </div>



</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larajet\resources\views\article\create.blade.php ENDPATH**/ ?>