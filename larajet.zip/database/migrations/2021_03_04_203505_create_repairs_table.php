<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRepairsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('repairs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('clientId'); 
            $table->timestamps();
            $table->text('description');
            $table->string('job');
            $table->string('price')->nullable();
            $table->text('comments')->nullable();
            $table->string('status'); // Terminada/En proceso/En tapiceria/En espera
            $table->string('paymentSign')->nullable();
            $table->foreign('clientId')->references('id')->on('clients')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('repairs');
    }
}
